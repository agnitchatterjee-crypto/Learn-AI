/* Deploy the synthetic SQL Server source platform.
   Run from this directory in SQLCMD mode, e.g.:
     sqlcmd -S localhost -d MigrationSource -E -i deploy.sql
   (create an empty database first; :r paths are relative to the working directory) */
SET NOCOUNT ON;
GO

-- 1. schemas and sequences
:r schemas/00_schemas.sql
GO
:r sequences/etl.seq_batch_id.sql
GO

-- 2. tables
:r tables/lnd/lnd.customer.sql
GO
:r tables/lnd/lnd.order_header.sql
GO
:r tables/lnd/lnd.order_line.sql
GO
:r tables/lnd/lnd.payment.sql
GO
:r tables/lnd/lnd.product.sql
GO
:r tables/lnd/lnd.shipment.sql
GO
:r tables/stg/stg.customer.sql
GO
:r tables/stg/stg.order_header.sql
GO
:r tables/stg/stg.order_line.sql
GO
:r tables/stg/stg.payment.sql
GO
:r tables/stg/stg.product.sql
GO
:r tables/stg/stg.shipment.sql
GO
:r tables/ref/ref.currency_rate.sql
GO
:r tables/dim/dim.customer.sql
GO
:r tables/dim/dim.date.sql
GO
:r tables/dim/dim.product.sql
GO
:r tables/fact/fact.order_line.sql
GO
:r tables/fact/fact.order_line_reject.sql
GO
:r tables/fact/fact.payment.sql
GO
:r tables/fact/fact.shipment.sql
GO
:r tables/agg/agg.customer_monthly_revenue.sql
GO
:r tables/etl/etl.load_audit.sql
GO
:r tables/etl/etl.pipeline_step.sql
GO
:r tables/etl/etl.watermark.sql
GO

-- 3. seed data and constraints
:r seed/01_unknown_members.sql
GO
:r seed/02_pipeline_steps.sql
GO
:r constraints/foreign_keys.sql
GO

-- 4. functions
:r functions/dbo.fn_business_days.sql
GO
:r functions/dbo.fn_clean_name.sql
GO
:r functions/dbo.fn_convert_currency.sql
GO
:r functions/dbo.fn_customer_tier.sql
GO
:r functions/dbo.fn_fiscal_period.sql
GO

-- 5. views
:r views/rpt.vw_customer_cohort_retention.sql
GO
:r views/rpt.vw_customer_current.sql
GO
:r views/rpt.vw_customer_revenue.sql
GO
:r views/rpt.vw_order_fulfilment_sla.sql
GO
:r views/rpt.vw_sales_daily.sql
GO

-- 6. procedures
:r procedures/etl/etl.usp_write_audit.sql
GO
:r procedures/etl/etl.usp_get_set_watermark.sql
GO
:r procedures/etl/etl.usp_rebuild_indexes.sql
GO
:r procedures/stg/stg.usp_load_customer.sql
GO
:r procedures/stg/stg.usp_load_orders.sql
GO
:r procedures/stg/stg.usp_load_payments.sql
GO
:r procedures/stg/stg.usp_load_product.sql
GO
:r procedures/stg/stg.usp_load_shipments.sql
GO
:r procedures/dim/dim.usp_load_dim_customer.sql
GO
:r procedures/dim/dim.usp_load_dim_date.sql
GO
:r procedures/dim/dim.usp_load_dim_product.sql
GO
:r procedures/fact/fact.usp_load_fact_order_line.sql
GO
:r procedures/fact/fact.usp_load_fact_payment.sql
GO
:r procedures/fact/fact.usp_load_fact_shipment.sql
GO
:r procedures/agg/agg.usp_refresh_customer_monthly_revenue.sql
GO
:r procedures/etl/etl.usp_run_daily_load.sql
GO
